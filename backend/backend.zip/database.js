module.exports = {
    db:"mongodb+srv://admin:12345@cluster0.arwhk.mongodb.net/jsDB?retryWrites=true&w=majority"
}